Building-Blocks
===============

Reusable components for Firefox OS


Cross brower support
-----------------------
Include `cross_browser.css` if you want your webapp can run on any browsers.


Install
----------

1. You can git clone the code from github `https://github.com/buildingfirefoxos/Building-Blocks.git`

2. Or if you have bower installed ([http://bower.io/](http://bower.io/)), run command: `$ bower install building-blocks`
